<?php
// Simulate a long-running process
sleep(3); // Simulates a delay of 3 seconds
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Loading Screen Example</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div id="loading-screen" class="loading-screen">
        <div class="loader"></div>
        <p>Loading, please wait...</p>
    </div>

    <div id="content" style="display: none;">
        <h1>Welcome to My Application</h1>
        <p>This is the main content of the page.</p>
    </div>

    <script src="script.js"></script>
</body>
</html>
