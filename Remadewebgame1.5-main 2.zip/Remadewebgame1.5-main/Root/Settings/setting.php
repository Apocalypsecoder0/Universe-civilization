<?php
// Database Configuration
$db_host = 'localhost'; // Database host
$db_user = 'username';  // Database username
$db_pass = 'password';  // Database password
$db_name = 'database_name'; // Database name

// Site Settings
$site_name = 'My Website'; // Name of the site
$site_url = 'http://www.mywebsite.com'; // URL of the site

// Debugging Options
$debug_mode = true; // Set to false in production

// Other Settings
$items_per_page = 10; // Number of items to display per page
$timezone = 'America/New_York'; // Default timezone
?>
