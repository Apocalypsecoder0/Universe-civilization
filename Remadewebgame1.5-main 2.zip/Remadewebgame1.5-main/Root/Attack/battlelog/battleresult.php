/ Display battle result
    echo "<h1>Battle Result</h1>";
    echo "<p>$result</p>";
