<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Missions</title>
</head>
<body>
    <h1>Your Missions</h1>
    <div id="missions">
        <?php include 'fetch_missions.php'; ?>
    </div>
</body>
</html>
