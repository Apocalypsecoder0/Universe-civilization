<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Friends List</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>My Friends List</h1>
        <ul id="friends-list">
            <!-- Friends will be added here -->
        </ul>
        <input type="text" id="friend-name" placeholder="Add a friend's name">
        <button id="add-friend">Add Friend</button>
    </div>
    <script src="script.js"></script>
</body>
</html>
