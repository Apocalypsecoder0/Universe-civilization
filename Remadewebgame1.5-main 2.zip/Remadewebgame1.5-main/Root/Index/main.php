<div class="content">
    <h1>Welcome to OGame Menu Management</h1>
    <p>Your main content goes here.</p>
    <div id="preferences-section" style="display: none;">
        <h2>User Preferences</h2>
        <form id="preferences-form">
            <label for="preferences">Preferences:</label>
            <textarea id="preferences" name="preferences"></textarea>
            <button type="submit">Save Preferences</button>
        </form>
    </div>
</div>
