<div id="structures-section" style="display: none;">
    <h2>Manage Structures</h2>
    <form id="structure-form">
        <label for="structure_name">Structure Name:</label>
        <input type="text" id="structure_name" name="structure_name" required>
        <label for="level">Level:</label>
        <input type="number" id="level" name="level" required>
        <button type="submit">Add Structure</button>
    </form>
    <div id="structure-list"></div>
</div>
