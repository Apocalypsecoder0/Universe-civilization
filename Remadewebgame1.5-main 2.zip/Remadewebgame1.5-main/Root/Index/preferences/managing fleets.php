<div id="fleet-section" style="display: none;">
    <h2>Manage Fleets</h2>
    <form id="fleet-form">
        <label for="fleet_name">Fleet Name:</label>
        <input type="text" id="fleet_name" name="fleet_name" required>
        <label for="ship_count">Ship Count:</label>
        <input type="number" id="ship_count" name="ship_count" required>
        <button type="submit">Add Fleet</button>
    </form>
    <div id="fleet-list"></div>
</div>
