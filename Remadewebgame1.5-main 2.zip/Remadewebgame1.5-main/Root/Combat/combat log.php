combat log
